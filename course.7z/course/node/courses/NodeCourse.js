var express = require('express');
var http = require('http');

var parser=require('body-parser');
var fs=require('fs');
var exp = express()
var data = fs.readFileSync('./course.json')
exp.use(parser.json());
data = JSON.parse(data);
exp.route('/courses/get').get((req,res)=>{
    res.send(data);
});
exp.route('/courses/post').post((req,res)=>{
     console.log(req.body);
    data.push(req.body);
   
    fs.writeFileSync('course.json',JSON.stringify(data));
     res.send(data);
});
exp.listen(3000,()=>{
    console.log("Server  started on 3000........");
})