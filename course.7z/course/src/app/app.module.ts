import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router'
import { AppComponent } from './app.component';
import { CourseComponent } from './course/course.component';
import { CoursesModule } from './/courses.module';
import {CoursesService} from './courses.service';
import {FormsModule} from '@angular/forms';
import { CourselistComponent } from './courselist/courselist.component';
import { JsoncourseComponent } from './jsoncourse/jsoncourse.component';
import {HttpClientModule} from '@angular/common/http'
const approuter:Routes=[
   
  {path:'course',component:CourselistComponent},
  {path:'jsoncourse',component:JsoncourseComponent}
  

];
@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    CourselistComponent,
    JsoncourseComponent
    
  ],
  imports: [
    BrowserModule,
    CoursesModule,RouterModule.forRoot(approuter),
    FormsModule,HttpClientModule
  ],
  providers: [CoursesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
