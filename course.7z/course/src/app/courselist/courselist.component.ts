import { Component, OnInit } from '@angular/core';
import {CoursesService} from '../courses.service'
@Component({
  selector: 'app-courselist',
  templateUrl: './courselist.component.html',
  styleUrls: ['./courselist.component.css']
})
export class CourselistComponent implements OnInit {
courses=[];
cName:string;
cDuration:number;
cTime:string;
  constructor(private courseService:CoursesService) { }

  ngOnInit() {
    this.courseService.getCourses().
    subscribe(data=>(this.courses=data));
  }
   addCourse(){
     console.log(this.cName,this.cDuration,this.cTime);
     this.courseService.postCourse(this.cName,this.cDuration,this.cTime).subscribe((data:any)=>{
         this.courseService.getCourses().
    subscribe(data=>(this.courses=data));
     });
   }

}
