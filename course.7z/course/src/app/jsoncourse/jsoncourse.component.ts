import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jsoncourse',
  templateUrl: './jsoncourse.component.html',
  styleUrls: ['./jsoncourse.component.css']
})
export class JsoncourseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
