import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JsoncourseComponent } from './jsoncourse.component';

describe('JsoncourseComponent', () => {
  let component: JsoncourseComponent;
  let fixture: ComponentFixture<JsoncourseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JsoncourseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JsoncourseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
